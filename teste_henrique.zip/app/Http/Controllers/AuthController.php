<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard');
    }

    public function create(Request $request){
        $user = User::create([
            'name' => "Henrique",
            'email' => "henrique.marcandier@gmail.com",
            'password' => Hash::make("406899he")
        ]);

    }

    public function showLoginForm()
    {
        return view('admin.formLogin');
    }

    public function login(Request $request)
    {

        $credentials = [
            'email' => $request->email,
            'password' => $request->password
        ];
        if (Auth::attempt($credentials)){
            $login['success'] = true;
            $_SESSION['token'] = csrf_token();
            echo json_encode($login);
            return;
        }
        $login['success'] = false;
        $login['message'] = "Os dados informados não conferem!";
        echo json_encode($login);
        return;
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('admin.login');
    }
}
