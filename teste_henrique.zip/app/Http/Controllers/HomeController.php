<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('site.home');
    }
    public function getResult()
    {
        $retorno['success'] = true;
        switch ($_REQUEST['operator']){
            case '+':
                $total = $_REQUEST['value1'] + $_REQUEST['value2'];
            break;
            case '-':
                $total = $_REQUEST['value1'] - $_REQUEST['value2'];
            break;
            case '*':
                $total = $_REQUEST['value1'] * $_REQUEST['value2'];
            break;
            case '/':
                if ($_REQUEST['value1'] == 0 || $_REQUEST['value2'] == 0){
                    $total = 0;
                }
                else{
                    $total = $_REQUEST['value1'] / $_REQUEST['value2'];
                }
            break;
        }
        $retorno['message'] = number_format($total, 2, ',', '.');
        echo json_encode($retorno);
        return;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
