<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('site.home');
    }
    public function getResult(request $request)
    {
        if (!is_numeric($request->value1) || !is_numeric($request->value2)){
            $retorno['success'] = false;
            $retorno['message'] = "Não informe strings nos campos";
        }
        else{
            $retorno['success'] = true;
            switch ($request->operator){
                case '+':
                    $total = $request->value1 + $request->value2;
                break;
                case '-':
                    $total = $request->value1 - $request->value2;
                break;
                case '*':
                    $total = $request->value1 * $request->value2;
                break;
                case '/':
                    if ($request->value1 == 0 || $request->value2 == 0){
                        $total = 0;
                    }
                    else{
                        $total = $request->value1 / $request->value2;
                    }
                break;
            }
            $retorno['message'] = number_format($total, 2, ',', '.');
        }
        echo json_encode($retorno);
        return;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
