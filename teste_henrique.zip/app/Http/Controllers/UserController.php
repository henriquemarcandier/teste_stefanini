<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        global $param;
        if(Auth::check() && (($_SESSION['token'] == csrf_token() && Auth::user()->type == 1) || Auth::user()->type == 2)) {
            if (Auth::user()->type == 1) {
                $user = User::all();
            } else{
                $user = User::where('id', Auth::user()->id)->get();
            }
            foreach ($user as $key => $value) {
                if ($value->id == Auth::user()->id){
                    if (isset($value->img)){
                        $value->img = env('APP_URL')."storage/".$value->img;
                    } else{
                        $value->img = env('APP_URL')."img/user-avatar.svg";
                    }
                    $usuario = $value;
                }
            }
            return view('admin.listAllUsers', [
                'users' => $user,
                'user' => $usuario,
            ]);
        } else {
            return redirect()->route('admin.login')
                        ->with('error','Faça o seu login no sistema!');
        }
    }
     /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::check() && (($_SESSION['token'] == csrf_token() && Auth::user()->type == 1) || Auth::user()->type == 2)) {
            if (Auth::user()->type == 1) {
                $user = User::all();
            } else{
                return redirect()->route('usuario.index')
                    ->with('error','Não é possível editar as informações de outro usuário!');
                exit;
            }
            foreach ($user as $key => $value) {
                if ($value->id == Auth::user()->id){
                    if (isset($value->img)){
                        $value->img = env('APP_URL')."storage/".$value->img;
                    } else{
                        $value->img = env('APP_URL')."img/user-avatar.svg";
                    }
                    $usuario = $value;
                }
            }
            return view('admin.newUser', [
                'users' => $user,
                'user' => $usuario,
            ]);
        } else {
            return redirect()->route('admin.login')
                        ->with('error','Faça o seu login no sistema!');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(Auth::check() && (($_SESSION['token'] == csrf_token() && Auth::user()->type == 1) || Auth::user()->type == 2)) {
            $verificaEmail = User::where('email', $request->email)->first();
            if (isset($verificaEmail->id)){
                return redirect()->route('usuario.index')
                ->with('error','Já existe um usuário com esse email cadastrado!');
            }
            else{
                $user = User::create([
                    "name" => $request->name,
                    "email" => $request->email,
                    "type" => $request->type,
                    "password" => $request->password
                ]);
                if (!$_FILES['img']['error']){
                    if (preg_match('/.jpg/', $_FILES['img']['name'])){
                        $img = "user".$request->id.".jpg";
                    } elseif (preg_match('/.jpeg/', $_FILES['img']['name'])){
                        $img = "user".$request->id.".jpeg";
                    } elseif (preg_match('/.gif/', $_FILES['img']['name'])){
                        $img = "user".$request->id.".gif";
                    } elseif (preg_match('/.png/', $_FILES['img']['name'])){
                        $img = "user".$request->id.".png";
                    } elseif (preg_match('/.svg/', $_FILES['img']['name'])){
                        $img = "user".$request->id.".svg";
                    }elseif (preg_match('/.webp/', $_FILES['img']['name'])){
                        $img = "user".$request->id.".webp";
                    }
                    if (isset($img)){
                        @unlink(env('APP_DIR')."storage/user".$user->id.".jpg");
                        @unlink(env('APP_DIR')."storage/user".$user->id.".jpeg");
                        @unlink(env('APP_DIR')."storage/user".$user->id.".gif");
                        @unlink(env('APP_DIR')."storage/user".$user->id.".png");
                        @unlink(env('APP_DIR')."storage/user".$user->id.".bmp");
                        @unlink(env('APP_DIR')."storage/user".$user->id.".svg");
                        @unlink(env('APP_DIR')."storage/user".$user->id.".webp");
                        copy($_FILES['img']['tmp_name'], env('APP_DIR')."storage/".$img);
                        $user->img = $img;
                        $user->save();
                    }
                }
                if (!isset($img)){
                    $user->img = null;
                    $user->save();
                }
                return redirect()->route('usuario.index');
            }
        } else {
            return redirect()->route('admin.login')
                        ->with('error','Faça o seu login no sistema!');
        }
    }    /**
     * Display the specified resource.
     *
     * @param  \App\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if(Auth::check() && (($_SESSION['token'] == csrf_token() && Auth::user()->type == 1) || Auth::user()->type == 2)) {
            if (Auth::user()->type == 1) {
                $users = User::all();
            } else{
                if (Auth::user()->id != $id){
                    return redirect()->route('usuario.index')
                    ->with('error','Não é possível ver as informações de outro usuário!');
                }
                $users = User::where('id', Auth::user()->id)->get();
            }
            foreach ($users as $key => $value) {
                if ($value->id == Auth::user()->id){
                    if (isset($value->img)){
                        $value->img = env('APP_URL')."storage/".$value->img;
                    } else{
                        $value->img = env('APP_URL')."img/user-avatar.svg";
                    }
                    $usuario = $value;
                }
            }
            $user = User::where('id', $id)->first();
            return view('admin.listUser', [
                'user2' => $user,
                'user' => $usuario

            ]);
        } else {
            return redirect()->route('admin.login')
                        ->with('error','Faça o seu login no sistema!');
        }
    }

    public function deleteImg($id){
        if(Auth::check() && (($_SESSION['token'] == csrf_token() && Auth::user()->type == 1) || Auth::user()->type == 2)) {
            if (Auth::user()->type != 1 && Auth::user()->id != $id){
                return redirect()->route('usuario.index')
                ->with('error','Não é possível excluir a imagem as informações de outro usuário!');
            }
            $user = User::where('id', $id)->first();
            if ($user->img){
                @unlink(env('APP_DIR')."storage/".$user->img);
            }
            $user->img = null;
            $user->save();
            return redirect()->route('usuario.index')
                        ->with('success','Imagem excluída com sucesso!');
        }
        else{
            return redirect()->route('admin.login')
                        ->with('error','Faça o seu login no sistema!');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(Auth::check() && (($_SESSION['token'] == csrf_token() && Auth::user()->type == 1) || Auth::user()->type == 2)) {
            if (Auth::user()->type == 1) {
                $users = User::all();
            } else{
                if (Auth::user()->id != $id){
                    return redirect()->route('usuario.index')
                    ->with('error','Não é possível editar as informações de outro usuário!');
                }
                $users = User::where('id', Auth::user()->id)->get();
            }
            foreach ($users as $key => $value) {
                if ($value->id == Auth::user()->id){
                    if (isset($value->img)){
                        $value->img = env('APP_URL')."storage/".$value->img;
                    } else{
                        $value->img = env('APP_URL')."img/user-avatar.svg";
                    }
                    $usuario = $value;
                }
            }
            $user = User::where('id', $id)->first();
            return view('admin.editUser', [
                'user2' => $user,
                'user' => $usuario

            ]);
        } else {
            return redirect()->route('admin.login')
                        ->with('error','Faça o seu login no sistema!');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        if(Auth::check() && (($_SESSION['token'] == csrf_token() && Auth::user()->type == 1) || Auth::user()->type == 2)) {
            $user2 = User::find($request->id);
            if ($request->email != $user2->email){
                $verificaEmail = User::where('email', $request->email)->first();
                if (isset($verificaEmail->id)){
                    return redirect()->route('usuario.index')
                    ->with('error','Já existe um usuário com esse email cadastrado!');
                }
            }
            $user2['id'] = $request->id;
            $user2['name'] = $request->name;
            $user2['email'] = $request->email;
            $user2['type'] = $request->type;
            $user2['password'] = $request->password;
            if (!$_FILES['img']['error']){
                if (preg_match('/.jpg/', $_FILES['img']['name'])){
                    $img = "user".$request->id.".jpg";
                } elseif (preg_match('/.jpeg/', $_FILES['img']['name'])){
                    $img = "user".$request->id.".jpeg";
                } elseif (preg_match('/.gif/', $_FILES['img']['name'])){
                    $img = "user".$request->id.".gif";
                } elseif (preg_match('/.png/', $_FILES['img']['name'])){
                    $img = "user".$request->id.".png";
                } elseif (preg_match('/.svg/', $_FILES['img']['name'])){
                    $img = "user".$request->id.".svg";
                }elseif (preg_match('/.webp/', $_FILES['img']['name'])){
                    $img = "user".$request->id.".webp";
                }
                if (isset($img)){
                    @unlink(env('APP_DIR')."storage/user".$request->id.".jpg");
                    @unlink(env('APP_DIR')."storage/user".$request->id.".jpeg");
                    @unlink(env('APP_DIR')."storage/user".$request->id.".gif");
                    @unlink(env('APP_DIR')."storage/user".$request->id.".png");
                    @unlink(env('APP_DIR')."storage/user".$request->id.".bmp");
                    @unlink(env('APP_DIR')."storage/user".$request->id.".svg");
                    @unlink(env('APP_DIR')."storage/user".$request->id.".webp");
                    copy($_FILES['img']['tmp_name'], env('APP_DIR')."storage/".$img);
                    $user2['img'] = $img;
                }
            }
            $user2->save();
            return redirect()->route('usuario.index')
                        ->with('success','Usuário editado com sucesso!');
        } else {
            return redirect()->route('admin.login')
                        ->with('error','Faça o seu login no sistema!');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if(Auth::check() && (($_SESSION['token'] == csrf_token() && Auth::user()->type == 1) || Auth::user()->type == 2)) {
            if (Auth::user()->type == '2' && Auth::user()->id != $id){
                return redirect()->route('usuario.index')
                ->with('error','Não é possível excluir as informações de outro usuário!');
            }
            $user = new User();
            $user = $user->findOrFail($id)->delete();

            @unlink(env('APP_DIR')."storage/user".$id.".jpg");
            @unlink(env('APP_DIR')."storage/user".$id.".jpeg");
            @unlink(env('APP_DIR')."storage/user".$id.".gif");
            @unlink(env('APP_DIR')."storage/user".$id.".png");
            @unlink(env('APP_DIR')."storage/user".$id.".bmp");
            @unlink(env('APP_DIR')."storage/user".$id.".svg");
            @unlink(env('APP_DIR')."storage/user".$id.".webp");
            return redirect()->route('usuario.index')
                        ->with('success','Usuário excluído com sucesso!');
        } else {
            return redirect()->route('admin.login')
                        ->with('error','Faça o seu login no sistema!');
        }
    }
}
