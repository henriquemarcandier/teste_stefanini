function abreFecha(id) {
    if(document.getElementById(id).style.display == ''){
        $("#"+id).hide('fast');
    }
    else{
        $("#"+id).show('slow');
    }
}
