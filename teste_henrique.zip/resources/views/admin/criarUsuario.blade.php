@extends('admin.master.layout')



@section('content')

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-2">
                        <h1 class="m-0 text-dark">Home</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href='{{env('APP_URL')}}admin/criar'>Criar Novo</button>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{env('APP_URL')}}admin">Home</a></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="media text-muted pt-3">
                @if (count($users))
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th style="padding:5px">ID</th>
                            <th style="padding:5px">Nome</th>
                            <th style="padding:5px">Email</th>
                            <th style="padding:5px">Tipo</th>
                            <th style="padding:5px">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach ($users as $value)
                        <tr>
                            <td style="padding:5px">{{$value->id}}</td>
                            <td style="padding:5px">{{$value->name}}</td>
                            <td style="padding:5px">{{$value->email}}</td>
                            <td style="padding:5px">{{($value->type == 1) ? "Administrador" : "Comum"}}</td>
                            <td style="padding:5px"><a href="{{env('APP_URL')}}admin/visualizar/{{$value->id}}"><img src="{{env('APP_URL')}}img/visualizar.svg" width="25"></a> <a href="{{env('APP_URL')}}admin/editar/{{$value->id}}"><img src="{{env('APP_URL')}}img/editar.svg" width="25"></a> <a href="{{env('APP_URL')}}admin/excluir/{{$value->id}}"><img src="{{env('APP_URL')}}img/excluir.svg" width="25"></a></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
                @endif
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
@endsection
