@extends('admin.master.layout')
@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1 class="m-0 text-dark">Usuários</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <a href="{{env('APP_URL')}}admin/usuario" class="btn btn-danger">&laquo; Voltar</a>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{env('APP_URL')}}admin">Home</a> | Usuários</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <form id="editaUsuario" action="{{route('usuario.update',$user2->id)}}" method='post' enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="modal-body">
                        <label for="type">Tipo:</label>
                        <select name="type" id="type" required class="form-control">
                            <option value="">Selecione o tipo do usuário corretamente...</option>
                            @if (Auth::user()->type == 1)
                            <option value="1" @if ($user2->type == 1) selected @endif>Administrador</option>
                            @endif
                            <option value="2" @if ($user2->type == 2) selected @endif>Comum</option>
                        </select>
                        <label for="name">Nome: </label>
                        <input type="text" name="name" id="name" value="{{$user2->name}}" required class="form-control" placeholder="Informe o nome do usuário corretamente...">
                        <label for="email">Email: </label>
                        <input type="email" name="email" id="email" value="{{$user2->email}}" required class="form-control" placeholder="Informe o email do usuário corretamente...">
                        <label for="password">Senha: </label>
                        <input type="password" name="password" id="password" value="" class="form-control" placeholder="Informe a senha do usuário corretamente...">
                        <label for="img">Imagem: </label>
                        <input type="file" name="img" id="img" class="form-control">
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Editar</button>
                        <button type="button" class="btn btn-danger" onclick="location.href='{{env('APP_URL')}}admin/usuario'">&laquo; Voltar</button>
                    </div>
                </form>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
@endsection
