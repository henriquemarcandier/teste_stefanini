<script>
    location.href="{{env('APP_URL')}}admin/usuario";
</script>
