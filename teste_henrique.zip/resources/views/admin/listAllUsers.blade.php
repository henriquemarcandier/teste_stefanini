@extends('admin.master.layout')
@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1 class="m-0 text-dark">Usuários</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        @if (Auth::user()->type == 1)
                        <a href="{{env('APP_URL')}}admin/usuario/criar" class="btn btn-primary">Novo Usuário</a>
                        @endif
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{env('APP_URL')}}admin">Home</a> | Usuários</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th style="padding:5px">ID</th>
                        <th style="padding:5px">Nome</th>
                        <th style="padding:5px">Email</th>
                        <th style="padding:5px">Tipo</th>
                        <th style="padding:5px">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $value)
                    <tr>
                        <td style="padding:5px">{{$value->id}}</td>
                        <td style="padding:5px">{{$value->name}}</td>
                        <td style="padding:5px">{{$value->email}}</td>
                        <td style="padding:5px">{{($value->type == 1) ? "Administrador" : "Comum"}}</td>
                        <td style="padding:5px">
                            <a href="{{env('APP_URL')}}admin/usuario/visualizar/{{$value->id}}"><img src="{{env('APP_URL')}}img/visualizar.svg" width="20"></a>
                            <a href="{{env('APP_URL')}}admin/usuario/editar/{{$value->id}}"><img src="{{env('APP_URL')}}img/editar.svg" width="20"></a>
                            <a style="cursor:pointer" onclick=excluirUsuario("{{$value->id}}","{{env('APP_URL')}}")><img src="{{env('APP_URL')}}img/excluir.svg" width="20"></a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
@endsection
