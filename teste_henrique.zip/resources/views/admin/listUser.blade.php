@extends('admin.master.layout')
@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1 class="m-0 text-dark">Usuários</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <a href="{{env('APP_URL')}}admin/usuario" class="btn btn-danger">&laquo; Voltar</a>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{env('APP_URL')}}admin">Home</a> | Usuários</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <form id="cadastroUsuario" action="{{route('usuario.store')}}" method='post' enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <label>Tipo:</label> {{($user2->type) ? "Administrador" : "Comum"}}<br>
                        <label>Nome: </label> {{$user2->name}}<br>
                        <label>Email: </label> {{$user2->email}}<br>
                        <label>Imagem: </label>
                        @if (isset($user2->img))
                        <img src="{{env('APP_URL')}}storage/{{$user2->img}}" width="100"> <button type="button" class="btn btn-primary" onclick="location.href='{{env('APP_URL')}}admin/usuario/excluirImg/{{$user2->id}}'">Excluir Imagem</button>
                        @else
                        <img src="{{env('APP_URL')}}img/user-avatar.svg" width="100">
                        @endif
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" onclick="location.href='{{env('APP_URL')}}admin/usuario'">&laquo; Voltar</button>
                    </div>
                </form>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
@endsection
