<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste do Henrique Marcandier</title>
</head>
<body>
    <form name="calcular" id="calcular">
    <input type='hidden' name='_token' id='token' value='{{ csrf_token() }}'>
    <input type="text" name="value1" id="value1" size="5" required>
    <select name="operator" id="operator" style="width:50px" required>
        <option value="">Selecione o operador abaixo corretamente</option>
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>
    </select>
    <input type="text" name="value2" id="value2" size="5" required>
    =
    <span class="result">Informe os valores e o operador corretamente...</span><br>
    <input type="submit" value="Calcular">
    </form>
	<script src="{{env('APP_URL')}}js/jquery.js" type="text/javascript"></script>
    <script type="text/javascript" src="{{env('APP_URL')}}js/jquery.form.min.js"></script>
    <script>
        $('form[name="calcular"]').submit(function(event){
            event.preventDefault();

            $.ajax({
                url: '{{env('APP_URL')}}cadastrar',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response){
                    $(".result").html(response.message);
                }
            });
        });
    </script>
</body>
</html>
