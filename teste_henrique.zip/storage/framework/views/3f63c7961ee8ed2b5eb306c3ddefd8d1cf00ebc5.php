<script>
    location.href="<?php echo e(env('APP_URL')); ?>admin/usuario";
</script>
<?php /**PATH D:\xampp2\htdocs\teste_henrique\resources\views/admin/home.blade.php ENDPATH**/ ?>