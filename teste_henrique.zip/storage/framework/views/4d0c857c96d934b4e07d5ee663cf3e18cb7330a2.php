<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1 class="m-0 text-dark">Usuários</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <a href="<?php echo e(env('APP_URL')); ?>admin/usuario/criar" class="btn btn-primary">Novo Usuário</a>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(env('APP_URL')); ?>admin">Home</a> | Usuários</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th style="padding:5px">ID</th>
                        <th style="padding:5px">Nome</th>
                        <th style="padding:5px">Email</th>
                        <th style="padding:5px">Tipo</th>
                        <th style="padding:5px">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="padding:5px"><?php echo e($value->id); ?></td>
                        <td style="padding:5px"><?php echo e($value->name); ?></td>
                        <td style="padding:5px"><?php echo e($value->email); ?></td>
                        <td style="padding:5px"><?php echo e(($value->type == 1) ? "Administrador" : "Comum"); ?></td>
                        <td style="padding:5px">
                            <a href="<?php echo e(env('APP_URL')); ?>admin/usuario/visualizar/<?php echo e($value->id); ?>"><img src="<?php echo e(env('APP_URL')); ?>img/visualizar.svg" width="20"></a>
                            <a href="<?php echo e(env('APP_URL')); ?>admin/usuario/editar/<?php echo e($value->id); ?>"><img src="<?php echo e(env('APP_URL')); ?>img/editar.svg" width="20"></a>
                            <a style="cursor:pointer" onclick=excluirUsuario("<?php echo e($value->id); ?>","<?php echo e(env('APP_URL')); ?>")><img src="<?php echo e(env('APP_URL')); ?>img/excluir.svg" width="20"></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\teste_henrique\resources\views/admin/listAllUsers.blade.php ENDPATH**/ ?>