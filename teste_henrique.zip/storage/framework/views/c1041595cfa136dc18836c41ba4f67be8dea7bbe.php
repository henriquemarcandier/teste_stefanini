<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1 class="m-0 text-dark">Usuários</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <a href="<?php echo e(env('APP_URL')); ?>admin/usuario" class="btn btn-danger">&laquo; Voltar</a>
                    </div><!-- /.col -->
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(env('APP_URL')); ?>admin">Home</a> | Usuários</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <form id="cadastroUsuario" action="<?php echo e(route('usuario.store')); ?>" method='post' enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <label>Tipo:</label> <?php echo e(($user2->type == 1) ? "Administrador" : "Comum"); ?><br>
                        <label>Nome: </label> <?php echo e($user2->name); ?><br>
                        <label>Email: </label> <?php echo e($user2->email); ?><br>
                        <label>Imagem: </label>
                        <?php if(isset($user2->img)): ?>
                        <img src="<?php echo e(env('APP_URL')); ?>storage/<?php echo e($user2->img); ?>" width="100"> <button type="button" class="btn btn-primary" onclick="location.href='<?php echo e(env('APP_URL')); ?>admin/usuario/excluirImg/<?php echo e($user2->id); ?>'">Excluir Imagem</button>
                        <?php else: ?>
                        <img src="<?php echo e(env('APP_URL')); ?>img/user-avatar.svg" width="100">
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" onclick="location.href='<?php echo e(env('APP_URL')); ?>admin/usuario'">&laquo; Voltar</button>
                    </div>
                </form>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\teste_henrique\resources\views/admin/listUser.blade.php ENDPATH**/ ?>