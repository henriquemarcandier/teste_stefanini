<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-2">
                        <h1 class="m-0 text-dark">Home</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href='<?php echo e(env('APP_URL')); ?>admin/criar'>Criar Novo</button>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(env('APP_URL')); ?>admin">Home</a></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="media text-muted pt-3">
                <?php if(count($users)): ?>
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th style="padding:5px">ID</th>
                            <th style="padding:5px">Nome</th>
                            <th style="padding:5px">Email</th>
                            <th style="padding:5px">Tipo</th>
                            <th style="padding:5px">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="padding:5px"><?php echo e($value->id); ?></td>
                            <td style="padding:5px"><?php echo e($value->name); ?></td>
                            <td style="padding:5px"><?php echo e($value->email); ?></td>
                            <td style="padding:5px"><?php echo e(($value->type == 1) ? "Administrador" : "Comum"); ?></td>
                            <td style="padding:5px"><a href="<?php echo e(env('APP_URL')); ?>admin/visualizar/<?php echo e($value->id); ?>"><img src="<?php echo e(env('APP_URL')); ?>img/visualizar.svg" width="25"></a> <a href="<?php echo e(env('APP_URL')); ?>admin/editar/<?php echo e($value->id); ?>"><img src="<?php echo e(env('APP_URL')); ?>img/editar.svg" width="25"></a> <a href="<?php echo e(env('APP_URL')); ?>admin/excluir/<?php echo e($value->id); ?>"><img src="<?php echo e(env('APP_URL')); ?>img/excluir.svg" width="25"></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\teste_henrique\resources\views/admin/criarUsuario.blade.php ENDPATH**/ ?>