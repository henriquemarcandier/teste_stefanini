<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste do Henrique Marcandier</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <form name="calcular" id="calcular">
    <div class="alert alert-danger d-none messageBox">Uai</div>
    <?php echo csrf_field(); ?>
    <input type="text" name="value1" id="value1" size="5" required>
    <select name="operator" id="operator" style="width:50px" required>
        <option value="">Selecione o operador abaixo corretamente</option>
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>
    </select>
    <input type="text" name="value2" id="value2" size="5" required>
    =
    <span class="result">Informe os valores e o operador corretamente...</span><br><br>
    <input type="submit" value="Calcular" class="btn btn-primary">
    </form>
	<script src="<?php echo e(env('APP_URL')); ?>js/jquery.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(env('APP_URL')); ?>js/jquery.form.min.js"></script>
    <script>
        $('form[name="calcular"]').submit(function(event){
            event.preventDefault();

            $.ajax({
                url: '<?php echo e(env('APP_URL')); ?>cadastrar',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response){
                    if (response.success === true) {
                        $(".messageBox").addClass('d-none');
                        $(".result").html(response.message);
                    }
                    else{
                        $(".messageBox").removeClass('d-none').html(response.message);
                        $(".result").html('Erro');
                    }
                }
            });
        });
    </script>
</body>
</html>
<?php /**PATH D:\xampp2\htdocs\teste_henrique\resources\views/site/home.blade.php ENDPATH**/ ?>