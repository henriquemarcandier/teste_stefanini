<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sistema Administrativo da Loja do Alex - Login</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(env('APP_URL')); ?>plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(env('APP_URL')); ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(env('APP_URL')); ?>dist/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <div class="login-logo">
        <a href="<?php echo e(env('APP_URL')); ?>admin"><b>Sistema Administrativo do Teste do Henrique</b><br>Login</a>
    </div>
    <!-- /.login-logo -->
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Logue se abaixo:</p>

            <form method="post" id="formLogin" name="formLogin">
                <?php echo csrf_field(); ?>
                <div class="alert alert-danger d-none messageBox" role="alert"></div>
                <div class="alert alert-success d-none messageBoxSuccess" role="alert">
                </div>
                <div class="input-group mb-3">
                    <input type="email" class="form-control" placeholder="Seu Email" name="email" id="emailLogin" required>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" placeholder="Sua Senha" name="password" id="senhaLogin" required>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- /.col -->
                    <div class="col-4">
                        <button type="submit" class="btn btn-primary btn-block">Login</button>
                    </div>
                    <!-- /.col -->
                </div>
                <?php if(isset($_REQUEST['page'])): ?>
                <input type="hidden" id="urlVolta" name="urlVolta" value="<?php echo e($_REQUEST['page'] ? $_REQUEST['page'] : ""); ?>">
                <?php endif; ?>
            </form>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?php echo e(env('APP_URL')); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(env('APP_URL')); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(env('APP_URL')); ?>dist/js/adminlte.min.js"></script>
<script>
    $(function(){
        $("#formLogin").submit(function(event){
            event.preventDefault();
            $.ajax({
                url: '<?php echo e(route('admin.login.do')); ?>',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response){
                    if (response.success === true){
                        $(".messageBox").addClass('d-none');
                        location.href="<?php echo e(route('admin')); ?>";
                    }
                    else{
                        $(".messageBox").removeClass('d-none').html(response.message);
                    }
                    console.log(response);
                }
            });
        });
    });
</script>

</body>
</html>
<?php /**PATH D:\xampp2\htdocs\teste_henrique\resources\views/admin/formLogin.blade.php ENDPATH**/ ?>